import DoctorAIApp from '@/components/DoctorAIApp';
export default function Page(){ return <DoctorAIApp/> }
